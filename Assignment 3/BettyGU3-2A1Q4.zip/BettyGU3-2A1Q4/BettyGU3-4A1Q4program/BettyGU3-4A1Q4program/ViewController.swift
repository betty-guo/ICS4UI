/*
 Unit 3-4 Assignment 1 Question 4
 Betty Guo
 Creation Date: 05/19/18
 Problem: Create a navigation app
 
 REFERENCE:
 https://developer.apple.com/
 PHOTO CREDITS:
 Arrows: https://pngtree.com/so/four-directional-arrows
 UP: https://www.pinterest.com/pin/490751690628052987/
 DOWN: http://iphonewallpaperclub.com/dirt-texture/
 LEFT: https://wallpapers.pictures/road-wallpapers-for-iphone-7
 RIGHT: http://theiphonewalls.com/wp-content/uploads/2013/09/Adorable-Kitten.jpg
 */

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

