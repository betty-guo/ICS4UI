import javax.swing.*;

public class GUI {
    public JComboBox citySelect;
    public JTable infoTable;
    public JPanel main;
    private JTextPane welcomeToWeatherProgramTextPane;
}
